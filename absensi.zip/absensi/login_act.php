<?php 
session_start();
include 'admin/config.php';
$uname=$_POST['uname'];
$pass=$_POST['pass'];
$query=("select * from admin where username='$uname' and password='$pass'");
$sql=mysqli_query($db,$query);
if(mysqli_num_rows($sql)==1){
	$_SESSION['username']=$uname;
	header("location:admin/index.php");
}else{
	header("location:index.php?pesan=gagal")or die(mysqli_error());
	// mysql_error();
}
// echo $pas;
 ?>