<?php 
include 'config.php';
include 'header.php'; ?>

<h3><span class="glyphicon glyphicon-file"></span>  Absensi Pegawai </h3>
<a class="btn" href="absensi.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<form method="get">
<label>PILIH TANGGAL</label>
<input type="date" name="tanggal_masuk">
<input type="submit" value="FILTER">
</form>
<a style="margin-bottom:10px" href="cetak.php" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Cetak</a>
<br/>
<br/>
<table class="table table-hover">
	<tr>
		<th width="20" class="col-md-1">No</th>
		<th width="25" class="col-md-2">Id E-KTP</th>
		<th width="118" class="col-md-3">Nama Pegawai</th>
		<th width="25" class="col-md-2">Tanggal Masuk</th>
		<th width="49" class="col-md-1">Status</th>
		<th width="110" class="col-md-10">Opsi</th>
	</tr>
	<?php
	$peg=("select * from absensi");
	$sql=mysqli_query($db,$peg);
	$no=1;
	while($b=mysqli_fetch_array($sql)){
	?>
	
	<?php 
	$no=1;
	if(isset($_GET['tanggal_masuk'])){
		$tanggal_masuk=$_GET['tanggal_masuk'];
		$sql =mysqli_query($db, "select * from absensi where tanggal_masuk='$tanggal_masuk' ");
	}else{$sql =mysqli_query($db, "select * from absensi");
		
	}
	while($b=mysqli_fetch_array($sql)){

		?>
		<tr>
			<td><?php echo $no++ ?></td>
			<td><?php echo $b['id_ektp'] ?></td>
			<td><?php echo $b['nama_pegawai'] ?></td>
			<td><?php echo $b['tanggal_masuk'] ?></td>
			<td><?php echo $b['status'] ?></td>
			<td><a href="det_absensi.php?id_ektp=<?php echo $b['id_ektp']; ?>" class="btn btn-info">Detail</a> <a onclick="if(confirm('Apakah anda yakin ingin menghapus data ini ??')){ location.href='hapus_absensi.php?id_ektp=<?php echo $b['id_ektp']; ?>' }" class="btn btn-danger">Hapus</a> </td>
			<td>&nbsp;</td>
		</tr>		
		<?php 
	}
	}
	?>
</table>
<!--<p>
  <!-- modal input 
</p>
<div id="myModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Tambah Absensi Pegawai</h4>
			</div>
			<div class="modal-body">
				<form action="tmb_absensi_act.php" method="post">
					<div class="form-group">
						<label>ID EKTP </label>
						<input name="id_ektp" type="text" class="form-control" id="id_ektp" placeholder="ID E-KTP ..">
					</div>
					<div class="form-group">
						<label>Nama Pegawai</label>
						<input name="nama_pegawai" type="text" class="form-control" id="nama_pegawai" placeholder="Nama Pegawai ..">
					</div>
					<div class="form-group">
						<label>Jenis Kelamin</label><br>
						<input type="radio" name="jenis_kelamin" value="L">&nbsp;&nbsp;L&nbsp;&nbsp;&nbsp;&nbsp;
						<input type="radio" name="jenis_kelamin" value="P">&nbsp;&nbsp;P<br>
					</div>
					<div class="form-group">
						<label>Alamat</label>
						<input name="alamat" type="text" class="form-control" id="alamat" placeholder="Alamat Lengkap ..">
					</div>
					<div class="form-group">
						<label>Tempat Lahir</label>
						<input name="tempat_lahir" type="text" class="form-control" id="tempat_lahir" placeholder="Tempat Lahir ..">
					</div>
					<div class="form-group">
						<label>Tanggal Lahir</label><br>
					    <input type="date" name="tanggal_lahir" id="textfield"/>
					</div>
					<div class="form-group">
						<label>No.Telp</label>
						<input name="no_telepon" type="text" class="form-control" id="no_telepon" placeholder="contoh:081xxxxxxxxx ..">
					</div>
					<div class="form-group">
						<label>E-Mail</label>
						<input name="email" type="text" class="form-control" id="email" placeholder="contoh:email@gmail.com ..">
					</div>
				  <div class="form-group">
					  <label></label>
					</div>
					</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			</form>
		</div>
	</div>
</div>-->



<?php 
include 'footer.php';

?>