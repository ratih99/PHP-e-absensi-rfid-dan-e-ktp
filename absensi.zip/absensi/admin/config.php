<?php
$host = "localhost";
$user = "root";
$pass = "";
$database ="absensi";
$db = mysqli_connect($host,$user,$pass,$database)or die("gagal koneksi ke database");

?>