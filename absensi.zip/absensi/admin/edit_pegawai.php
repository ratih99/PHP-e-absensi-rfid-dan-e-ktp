<?php 
include 'header.php';
?>
<h3><span class="glyphicon glyphicon-user"></span>  Edit Pegawai</h3>
<a class="btn" href="pegawai.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
$id_ektp=($_GET['id_ektp']);
mysqli_real_escape_string($db,$id_ektp);
$det=("select * from pegawai where id_ektp='$id_ektp'");
$sql=mysqli_query($db,$det);
while($d=mysqli_fetch_array($sql)){
?>					
	<form action="update_pegawai.php" method="post">
		<table class="table">
			
			<tr>
				<td>Id EKTP</td>
				<td><input name="id_ektp" type="text" class="form-control" id="id_ektp" value="<?php echo $d['id_ektp'] ?>"></td>
			</tr>
			<tr>
				<td>Nama Pegawai</td>
				<td><input name="nama_pegawai" type="text" class="form-control" id="nama_pegawai" value="<?php echo $d['nama_pegawai'] ?>"></td>
			</tr>
			<tr>
				<td>Jenis Kelamin</td>
				<td><input name="jenis_kelamin" type="text" class="form-control" id="jenis_kelamin" value="<?php echo $d['jenis_kelamin'] ?>"></td>
			</tr>
		<tr>
				<td>Alamat</td>
				<td><input name="alamat" type="text" class="form-control" id="alamat" value="<?php echo $d['alamat'] ?>"></textarea></td>
			</tr>
			<tr>
				<td>Tempat Lahir</td>
				<td><input name="tempat_lahir" type="text" class="form-control" id="tempat_lahir" value="<?php echo $d['tempat_lahir'] ?>"></td>
			</tr>
			<tr>
				<td>Tanggal Lahir</td>
				<td><input name="tanggal_lahir" type="text" class="form-control" id="tanggal_lahir" value="<?php echo $d['tanggal_lahir'] ?>"></td>
			</tr>
			<tr>
				<td>No.Telp</td>
				<td><input name="no_telepon" type="text" class="form-control" id="no_telepon" value="<?php echo $d['no_telepon'] ?>"></td>
			</tr>
			<tr>
				<td>Email</td>
				<td><input name="email" type="text" class="form-control" id="email" value="<?php echo $d['email'] ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Simpan"></td>
			</tr>
		</table>
	</form>
	<?php 
}
?>
<?php include 'footer.php'; ?>