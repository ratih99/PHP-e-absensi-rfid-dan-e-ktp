<!DOCTYPE html>
<html>
<head>
	<title>CETAK PRINT DATA ABSENSI PEGAWAI</title>
</head>
<body>
 
	<center>
 
		<h2>DATA LAPORAN ABSENSI PEGAWAI</h2>
 
	</center>
 
	<?php 
	include 'config.php';
	?>
 
	<table border="1" style="width: 100%">
		<tr>
			<th width="1%">No</th>
			<th>ID EKTP</th>
			<th>TANGGAL ABSEN</th>
			<th>NAMA</th>
			<th>JAM MASUK</th>
			<th>STATUS MASUK</th>
			<th>JAM PULANG</th>
			<th>STATUS PULANG</th>
		</tr>
		<?php 
		$no = 1;
		$sql = mysqli_query($db,"select * from t_absen inner join pegawai where t_absen.id_ektp=pegawai.id_ektp");
		while($data = mysqli_fetch_array($sql)){
		?>
		<tr>
			<td><?php echo $no++; ?></td>
			<td><?php echo $data['id_ektp']; ?></td>
			<td><?php echo $data['tgl_absen']; ?></td>
			<td><?php echo $data['nama_pegawai']; ?></td>
			<td><?php echo $data['jam_msk']; ?></td>
			<td><?php echo $data['id_st_msk']; ?></td>
			<td><?php echo $data['jam_plg']; ?></td>
			<td><?php echo $data['id_st_plg']; ?></td>
		</tr>
		<?php 
		}
		?>
	</table>
 
	<script>
		window.print();
	</script>
 
</body>
</html>