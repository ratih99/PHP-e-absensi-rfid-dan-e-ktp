<?php 
include 'config.php';
$id_ektp=$_GET['id_ektp'];
$det=("delete from pegawai where id_ektp='$id_ektp'");
$sql=mysqli_query($db,$det);
header("location:pegawai.php");

?>