<?php 
include 'header.php';
?>

<h3><span class="glyphicon glyphicon-file"></span>Detail Absensi</h3>
<a class="btn" href="absensirfid.php"><span class="glyphicon glyphicon-arrow-left"></span>Kembali</a>

<?php 
$id_ektp=($_GET['id_ektp']);
mysqli_real_escape_string($db,$id_ektp);
	if(isset($_GET['tanggal_masuk'])){
		$tanggal_masuk=$_GET['tanggal_masuk'];
		$sql =mysqli_query($db, "select * from t_absen inner join pegawai where t_absen.id_ektp=pegawai.id_ektp");
	}else{$sql =mysqli_query($db, "select * from t_absen inner join pegawai where t_absen.id_ektp=pegawai.id_ektp");
		
	}
	while($b=mysqli_fetch_array($sql)){

		?>					
	<table class="table">
		
		<tr>
			<td>ID E-KTP</td>
			<td><?php echo $b['id_ektp'] ?></td>
		</tr>
		<tr>
			<td>TANGGAL ABSEN</td>
			<td><?php echo $b['tgl_absen'] ?></td>
		</tr>
		<tr>
			<td>NAMA</td>
			<td><?php echo $b['nama_pegawai'] ?></td>
		</tr>
		<tr>
			<td>JAM MASUK</td>
			<td><?php echo $b['jam_msk'] ?></td>
		</tr>
		<tr>
			<td>STATUS MASUK</td>
			<td><?php echo $b['id_st_msk'] ?></td>
		</tr>
		<tr>
			<td>JAM PULANG</td>
			<td><?php echo $b['jam_plg'] ?></td>
		</tr>
		<tr>
			<td>STATUS PULANG</td>
			<td><?php echo $b['id_st_plg'] ?></td>
		</tr>
	</table>
	<?php 
}
?>
<?php include 'footer.php'; ?>