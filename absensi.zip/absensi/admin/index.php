<?php 
include 'header.php';
?>



<div class="col-md-10">
	<h3 align="center">Selamat Datang</h3>	
    <h3 align="center">Sistem Informasi Absensi Pegawai Kantor Desa Klitik</h3>
    <h3 align="center">Jln.P.Sudirman No. 39 Desa Klitik Kecamatan Wonoasri Kabupaten Madiun</h3>
	<h3 align="center">63157</h3>
</div>
<!-- kalender -->
<div class="pull-right">
	<div id="kalender"></div>
</div>

<?php 
include 'footer.php';

?>