<?php 
include 'header.php';
?>

<h3><span class="glyphicon glyphicon-user"></span>  Detail Pegawai</h3>
<a class="btn" href="pegawai.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>

<?php
$id_ektp=($_GET['id_ektp']);
mysqli_real_escape_string($db,$id_ektp);
$det=("select * from pegawai where id_ektp='$id_ektp'");
$sql=mysqli_query($db,$det);
while($d=mysqli_fetch_array($sql)){
	?>					
	<table class="table">
		<tr>
			<td>ID E-KTP</td>
			<td><?php echo $d['id_ektp'] ?></td>
		</tr>
		<tr>
			<td>Nama Pegawai</td>
			<td><?php echo $d['nama_pegawai'] ?></td>
		</tr>
		<tr>
			<td>Jenis Kelamin</td>
			<td><?php echo $d['jenis_kelamin'] ?></td>
		</tr>
		<tr>
			<td>Alamat</td>
			<td><?php echo $d['alamat'] ?></td>
		</tr>
		<tr>
			<td>Tempat Lahir</td>
			<td><?php echo $d['tempat_lahir'] ?></td>
		</tr>
		<tr>
			<td>Tanggal Lahir</td>
			<td><?php echo $d['tanggal_lahir'] ?></td>
		</tr>
		<tr>
			<td>No.Telp</td>
			<td><?php echo $d['no_telepon'] ?></td>
		</tr>
		<tr>
			<td>Email</td>
			<td><?php echo $d['email'] ?></td>
		</tr>
	</table>
	<?php 
}
?>
<?php include 'footer.php'; ?>