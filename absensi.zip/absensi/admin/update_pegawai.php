<?php 
include 'config.php';
$id_ektp=$_POST['id_ektp'];
$nama_pegawai=$_POST['nama_pegawai'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$alamat=$_POST['alamat'];
$tempat_lahir=$_POST['tempat_lahir'];
$tanggal_lahir=$_POST['tanggal_lahir'];
$no_telepon=$_POST['no_telepon'];
$email=$_POST['email'];
$up=("update pegawai set id_ektp='$id_ektp', nama_pegawai='$nama_pegawai',jenis_kelamin='$jenis_kelamin',alamat='$alamat', tempat_lahir='$tempat_lahir', tanggal_lahir='$tanggal_lahir', no_telepon='$no_telepon'  where id_ektp='$id_ektp'");
$sql=mysqli_query($db,$up);

header("location:pegawai.php");



?>
