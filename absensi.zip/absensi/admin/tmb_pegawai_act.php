<?php 
include 'config.php';
$id_ektp=$_POST['id_ektp'];
$nama_pegawai=$_POST['nama_pegawai'];
$jenis_kelamin=$_POST['jenis_kelamin'];
$alamat=$_POST['alamat'];
$tempat_lahir=$_POST['tempat_lahir'];
$tanggal_lahir=$_POST['tanggal_lahir'];
$no_telepon=$_POST['no_telepon'];
$email=$_POST['email'];
$det=("insert into pegawai values('$id_ektp','$nama_pegawai','$jenis_kelamin','$alamat','$tempat_lahir','$tanggal_lahir','$no_telepon','$email')");
$sql=mysqli_query($db,$det);
{
	header("location:pegawai.php");
}
	?>					

