<?php 
include 'config.php';
$id_ektp=$_GET['id_ektp'];
$det=("delete from absensi where id_ektp='$id_ektp'");
$sql=mysqli_query($db,$det);
header("location:absensi.php");

?>